i = int(input("See all the powers of 2, state a power.\nDon't put anything too big if you are not eager to wait forever: "))

n = 2**i
print(n)
while n > 0:
    n /= 2
    if n == 2:
        break
    print(int(n))
print('End.')
