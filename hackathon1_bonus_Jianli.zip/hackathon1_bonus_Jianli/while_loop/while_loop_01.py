i = 20
while i > 0:
    i -= 1
    print(i)
