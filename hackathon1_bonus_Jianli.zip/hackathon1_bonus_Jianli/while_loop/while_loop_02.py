n = 3
while n < 54:
    n += 3
    print(n)
