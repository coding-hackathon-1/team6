n = int(input("Input a number that you wanna divide by 2 forever: "))
while n > 0:
    n /= 2
    if n == 2:
        continue
    print(n)
print("uff... it finally ended.")
