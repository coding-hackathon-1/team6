v1 = ['y','e','a','h',' ','b','o','i','i','i','i']
while v1:
    print(v1.pop(0))
