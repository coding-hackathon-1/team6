lst = ['a', 'b', 'c', 'd', 'e']

for s in lst: print(s)

#printing all the different elements
#during the exam I misplaced the print statement and also used the wrong attribute in print.
