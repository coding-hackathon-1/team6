well, I misread the assignment and i waste some time, since I don't wanna waste them, here you go, just for fun.

---EDIT---
since I just coded one and half HTML page and I did not really had any problem other than the CSS (which Django often gives for no apparent reason, ask Rana when she gave us the CSS code) and what we were doing was not working on the front end, I did not really had any problem, so I'll just stick with the examples from the exam.