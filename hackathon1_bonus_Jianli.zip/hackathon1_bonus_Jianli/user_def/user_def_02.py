def times3(x, y, z):
    """insert three numbers and see if all the numbers are multiples of 3"""
    if (x % 3) == 0 and (y % 3) == 0 and (z % 3) == 0:
        print("The number", x, ",", y,"and", z,"are multiples of 3.")
    else:
        print("One or more of the numbers is/are not multiples of 3")
