def f_to_c(x):
    return float((x-32)*5/9)

def m_to_k(x):
    return float(x*1.609)

print("You're European and you don't understand a thing when American people use Imperial system instead of the Metric system?")

while True:
    
    sel = input("Input T to convert Fahrenheit to Celcius\nInput L to convert Miles to Km: ").upper()
    
    if sel == "T":
        f = float(input("Insert the temperature in Fahrenheit: "))
        print("The equivalent is {:0.2f}°C.".format(f_to_c(f)))
        break
    
    if sel == "L":
        m = float(input("Insert the lenght in Miles: "))
        print("The equivalent is {:0.2f}km!".format(m_to_k(m)))
        break
    
    print("\n\nWrong input, try again.\n\n")
        
