def avg_vote(v1,v2,v3,v4,v5):
    """put 5 of your votes to see your average."""
    return print("The average of your votes is", (v1+v2+v3+v4+v5)/5)
