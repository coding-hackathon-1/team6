def pyth_theor(x, y):
    """define the two perpendicular sides of the triangle to find the hypotenuse"""
    return ((x**2 + y**2)**(1/2.0))

n1 = float(input("first side: "))
n2 = float(input("second side: "))

print("The hypotenuse is: ", pyth_theor(n1, n2) )
