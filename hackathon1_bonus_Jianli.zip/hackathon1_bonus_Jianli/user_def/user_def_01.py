def square(x):
    """insert a number to get the square of it"""
    return x**2

def cube(x):
    """insert a number to get the cube of it"""
    return x**3

print("to get the square of a number, write square(number).\nto get the cude of a number, write cube(number).")
