Jianli Lin

ALL CODES ARE WRITTEN WITH PYTHON IDLE 3.7.3

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Jupyter notebook is great, but after used a code to get rid of the auto filling I ran into a few problems. (extremely long processing time, even if I have an i7 7700k; inability to save some files; automatic changes from codes to headmarks etc...)
Therefore, I just stick with IDLE and .txt, they are simple but powerful, and the simplier, the most reliable.

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

I could not find any assignment in the modules, so this is the reason why I sent everything via email, I hope I did not bother you.

--- EDIT ---

hopefully you'll accept them in this way, I just saw that the assignment was on